# -*- coding: utf-8 -*-
"""
Genera las tablas (tablas/*.tex) y figuras (figuras/*.pdf) del reporte IEEE a partir de
los resultados ya calculados (resultados/*.json) y de los diccionarios PAPER_* del codigo.
No resuelve ningun modelo ni retipea cifras: todo sale de esos archivos.

Uso (desde cualquier carpeta):   python scripts/generar_tablas_figuras.py
Requiere: matplotlib; y los modulos de codigo/ (datos_garver, datos_rts24, datos_heydari,
que importa gurobipy).  Busca resultados/ y codigo/ junto a esta carpeta o en la carpeta
superior (estructura del proyecto original).
"""
import json
import os
import sys

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _carpeta(nombre):
    for c in (os.path.join(BASE, nombre), os.path.join(os.path.dirname(BASE), nombre)):
        if os.path.isdir(c):
            return c
    raise SystemExit(f"no se encontro la carpeta '{nombre}' junto a {BASE}")


RES, COD = _carpeta("resultados"), _carpeta("codigo")
sys.path.insert(0, COD)
OUT_T, OUT_F = os.path.join(BASE, "tablas"), os.path.join(BASE, "figuras")
os.makedirs(OUT_T, exist_ok=True)
os.makedirs(OUT_F, exist_ok=True)

import datos_garver as G          # noqa: E402
import datos_rts24 as R           # noqa: E402
import datos_heydari as H         # noqa: E402
from sistema import parse_plan    # noqa: E402


def cargar(nombre):
    with open(os.path.join(RES, nombre), encoding="utf-8") as f:
        return json.load(f)


# ----------------------------------------------------------------------------- utilidades
def esc(s):
    return s.replace("&", r"\&").replace("%", r"\%").replace("_", r"\_").replace("#", r"\#")


def n(x, d=2, signed=False):
    """Numero con signo menos matematico (no guion) y, opcionalmente, mas explicito."""
    if x is None or x != x:
        return "--"
    if round(abs(x), d) == 0:
        return f"{0:.{d}f}"
    s = f"{abs(x):.{d}f}"
    if x < 0:
        return "$-$" + s
    return ("$+$" if signed else "") + s


def plan(s):
    """Texto de plan -> LaTeX (separador HVAC / HVDC)."""
    s = s.strip() or "--"
    return esc(s.replace("  |  HVDC: ", " / HVDC: "))


SI = "s\\'{\\i}"      # "s\'{\i}" en LaTeX


def mismo(a, b):
    return sorted(parse_plan(a.split("|")[0].strip()).items()) == sorted(parse_plan(b.split("|")[0].strip()).items())


def escribir(nombre, lineas):
    with open(os.path.join(OUT_T, nombre), "w", encoding="utf-8", newline="\n") as f:
        f.write("\n".join(lineas) + "\n")


# ----------------------------------------------------------------------------- TABLAS
def tabla_garver():
    g = cargar("garver_resultados.json")
    P = G.PAPER_TABLA_IV
    b = g["bilevel"]
    L = [r"\begin{tabular}{@{}P{1.4in}P{0.85in}P{0.85in}@{}}", r"\toprule",
         r"Concepto & Publicado & Reproducido \\", r"\midrule",
         f"Plan bilevel & {plan(P['Bilevel']['plan'])} & {plan(b['plan'])} \\\\",
         f"Inversi\\'on (\\MEUR) & {n(P['Bilevel']['inv'])} & {n(b['inv'], 3)} \\\\",
         f"Bienestar medio (\\MEUR/a\\~no) & {n(P['Bilevel']['swm'])} & {n(b['swm'], 3)} \\\\",
         f"CPU (s) & {n(P['Bilevel']['cpu'])} (CPLEX) & {n(b['t'])} (Gurobi) \\\\", r"\midrule"]
    for k in (1, 2, 3):
        nom = f"Min-costos Esc. {k}"
        L.append(f"Inversi\\'on, {nom.lower().replace('min-costos', 'min. costos')} & {n(P[nom]['inv'])} & {n(g[nom]['inv'], 3)} \\\\")
    for k in (1, 2, 3):
        nom = f"Min-costos Esc. {k}"
        L.append(f"Bienestar medio, plan publicado Esc.~{k} & {n(P[nom]['swm'])} & {n(g[nom]['swm_plan_paper'], 3)} \\\\")
    c = g["centralizado"]
    Pc = P["Basica y centralizada (tesis)"]
    L += [f"B\\'asico y centralizado: inversi\\'on & {n(Pc['inv'])} & {n(c['inv'], 3)} \\\\",
          f"B\\'asico y centralizado: bienestar medio & {n(Pc['swm'])} & {n(c['swm'])} \\\\",
          r"\bottomrule", r"\end{tabular}"]
    escribir("tab_garver.tex", L)


def tabla_garver_cont():
    g = cargar("garver_resultados.json")["contingencias"]
    L = [r"\begin{tabular}{@{}cllrrrr@{}}", r"\toprule",
         r"L\'inea fuera & Plan reproducido & Igual al publicado & \multicolumn{2}{c}{Inversi\'on (\MEUR)} & \multicolumn{2}{c}{Bienestar medio (\MEUR/a\~no)} \\",
         r"\cmidrule(lr){4-5}\cmidrule(lr){6-7}",
         r" & & & Publ. & Repr. & Publ. & Repr. \\", r"\midrule"]
    for cor, pf in G.PAPER_TABLA_V.items():
        r = g[f"{cor[0]}-{cor[1]}"]
        igual = SI if mismo(r['plan'], pf['plan']) else "NO"
        L.append(f"{cor[0]}-{cor[1]} & {plan(r['plan'])} & {igual} & "
                 f"{n(pf['inv'])} & {n(r['inv'])} & {n(pf['swm'])} & {n(r['swm'])} \\\\")
    L += [r"\bottomrule", r"\end{tabular}"]
    escribir("tab_garver_cont.tex", L)


def _err_rts():
    """(etiqueta, publicado, exactos, impresos) de las 11 cifras comparables del RTS-24."""
    s = cargar("rts24_sin_contingencia.json")
    c = cargar("rts24_contingencia_simple.json")
    m = cargar("rts24_multicontingencia.json")
    filas = []
    for nom, pf in R.PAPER_TABLA_VIII.items():
        v = s["swm_planes"][nom]
        filas.append((nom, pf["swm"], v["exactos"], v["impresos"]))
    for cor, pf in R.PAPER_CUADRO_6_9.items():
        filas.append((f"{cor[0]}-{cor[1]}", pf["swm"], c[f"{cor[0]}-{cor[1]}_exactos"]["swm"], c[f"{cor[0]}-{cor[1]}_impresos"]["swm"]))
    pw = m["swm_plan_paper"]
    filas.append(("Tabla X", pw["paper"], pw["bloques_exactos"]["pesos_exactos"], pw["bloques_impresos"]["pesos_impresos"]))
    return filas


def tabla_rts_viii():
    s = cargar("rts24_sin_contingencia.json")
    L = [r"\begin{tabular}{@{}P{1.35in}P{1.45in}rrrrr@{}}", r"\toprule",
         r"Aproximaci\'on & Plan publicado & \multicolumn{2}{c}{Inversi\'on (\MEUR)} & \multicolumn{3}{c}{Bienestar medio (\MEUR/a\~no)} \\",
         r"\cmidrule(lr){3-4}\cmidrule(lr){5-7}",
         r" & & Publ. & Repr. & Publ. & Err. exact. & Err. impr. \\", r"\midrule"]
    for nom, pf in R.PAPER_TABLA_VIII.items():
        inv = s["bilevel"]["inv"] if nom == "Bilevel" else s["costmin"][nom]["inv"]
        v = s["swm_planes"][nom]
        etiqueta = "Bilevel (Garc\\'es et al.)" if nom == "Bilevel" else nom.replace("Min-costos", "Min. costos")
        L.append(f"{etiqueta} & {plan(pf['plan'])} & {n(pf['inv'])} & {n(inv, 3)} & {n(pf['swm'])} & "
                 f"{n(v['exactos'] - pf['swm'], 3, True)} & {n(v['impresos'] - pf['swm'], 3, True)} \\\\")
    L += [r"\bottomrule", r"\end{tabular}"]
    escribir("tab_rts_viii.tex", L)


def tabla_rts_resto():
    c = cargar("rts24_contingencia_simple.json")
    m = cargar("rts24_multicontingencia.json")
    L = [r"\begin{tabular}{@{}lP{1.75in}rrrrr@{}}", r"\toprule",
         r"Caso & Plan (igual al publicado) & \multicolumn{2}{c}{Inversi\'on (\MEUR)} & \multicolumn{3}{c}{Bienestar medio (\MEUR/a\~no)} \\",
         r"\cmidrule(lr){3-4}\cmidrule(lr){5-7}",
         r" & & Publ. & Repr. & Publ. & Err. exact. & Err. impr. \\", r"\midrule"]
    for cor, pf in R.PAPER_CUADRO_6_9.items():
        k = f"{cor[0]}-{cor[1]}"
        re_, ri = c[k + "_exactos"], c[k + "_impresos"]
        ok = mismo(re_["plan"], pf["plan"]) and mismo(ri["plan"], pf["plan"])
        L.append(f"Cuadro 6.9, l\\'inea {k} fuera & {plan(pf['plan'])}{'' if ok else ' (*)'} & {n(pf['inv'])} & {n(re_['inv'])} & "
                 f"{n(pf['swm'])} & {n(re_['swm'] - pf['swm'], 3, True)} & {n(ri['swm'] - pf['swm'], 3, True)} \\\\")
    pf = R.PAPER_TABLA_X
    mx = m["oraculo_bloques-exactos_pesos-exactos"]
    pw = m["swm_plan_paper"]
    ok = mismo(mx["plan"], pf["plan"])
    L.append(f"Tabla X (22 escenarios) & {plan(pf['plan'])}{'' if ok else ' (*)'} & {n(pf['inv'])} & {n(mx['inv'])} & {n(pf['swm'])} & "
             f"{n(pw['bloques_exactos']['pesos_exactos'] - pf['swm'], 3, True)} & {n(pw['bloques_impresos']['pesos_impresos'] - pf['swm'], 3, True)} \\\\")
    filas = _err_rts()
    mae_e = sum(abs(e - p) for _, p, e, _ in filas) / len(filas)
    mae_i = sum(abs(i - p) for _, p, _, i in filas) / len(filas)
    L += [r"\midrule",
          f"\\multicolumn{{5}}{{l}}{{Error absoluto medio de las {len(filas)} cifras comparables (Tablas VIII, X y Cuadro 6.9)}} & {n(mae_e, 3)} & {n(mae_i, 3)} \\\\",
          r"\bottomrule", r"\end{tabular}"]
    escribir("tab_rts_resto.tex", L)
    return mae_e, mae_i, len(filas)


def tabla_heydari():
    s = cargar("reto2_segmentacion.json")
    cols = "@{}P{1.05in}" + "P{1.32in}" * 4 + "@{}"
    L = [f"\\begin{{tabular}}{{{cols}}}", r"\toprule",
         r"Concepto & Caso 1 (t\'ermicas) & Caso 2 (e\'olica, HVAC) & Caso 3 (e\'olica, HVAC+HVDC) & Caso 4 (caso 3 con CVaR) \\", r"\midrule"]

    def fila(nombre, f):
        L.append(nombre + " & " + " & ".join(f(s[str(c)]) for c in (1, 2, 3, 4)) + r" \\")

    fila("Plan HVAC / HVDC (publicado = \\'optimo del modelo)",
         lambda r: plan(r["paper"]["ac"] + ("  |  HVDC: " + r["paper"]["dc"] if r["paper"]["dc"] else "")) +
                   (" ($\\checkmark$)" if r["mismo_plan"] else " (NO)"))
    fila("Inversi\\'on (\\MUSD), publicada = reproducida", lambda r: n(r["paper"]["inv"], 1) if abs(r["paper"]["inv"] - r["ev"]["inv_total"]) < 1e-9 else "DIFIERE")
    fila("ESW publicado / reproducido (\\MUSD)",
         lambda r: f"{n(r['paper']['esw'])} / {n(r['ev']['esw'])} ({n(100 * (r['ev']['esw'] / r['paper']['esw'] - 1), 2, True)}\\,\\%)")
    fila("CVaR publicado / reproducido (\\MUSD)",
         lambda r: "--" if r["caso"] != 4 else f"{n(H.PAPER_TABLA_4[4]['cvar'])} / {n(r['ev']['cvar'])}")
    fila("Objetivo (1) publicado / reproducido (\\MUSD)", lambda r: f"{n(r['paper']['obj'])} / {n(r['ev']['obj'])}")
    fila("Racionamiento (GWh)", lambda r: "--" if r["caso"] == 1 else
         f"{n(r['paper']['consumo'] - r['paper']['fosil'] - r['paper']['eolica'])} / {n(r['ev']['GWh_racion'])}")
    fila("Energ\\'ia e\\'olica (GWh)", lambda r: "--" if r["caso"] == 1 else f"{n(r['paper']['eolica'])} / {n(r['ev']['GWh_eolica'], 1)}")
    fila("LMP medio (USD/MWh)", lambda r: f"{n(r['paper']['lmp'], 3)} / {n(r['ev']['lmp_medio'], 3)}")
    fila("LMP desv. t\\'ip. (USD/MWh)", lambda r: f"{n(r['paper']['lmp_std'], 3)} / {n(r['ev']['lmp_std'], 3)}")
    L += [r"\bottomrule", r"\end{tabular}"]
    escribir("tab_heydari.tex", L)


def tabla_dualidad():
    d = cargar("reto2_dualidad.json")
    L = [r"\begin{tabular}{@{}crrrr@{}}", r"\toprule",
         r"Caso & Objetivo & $\max|\varphi|$ & $t$ (s) & Obj. con $\Gamma=10^3$ \\", r"\midrule"]
    for c in ("1", "2", "3", "4"):
        r = d[c]
        igual = abs(r["gamma1000"]["obj"] - r["dual"]["obj"]) < 1e-6
        g = "igual" if igual else n(r["gamma1000"]["obj"], 2)
        L.append(f"{c} & {n(r['dual']['obj'], 2)} & {n(r['dual']['max_phi'], 0)} & {n(r['dual']['t'], 1)} & {g} \\\\")
    L += [r"\bottomrule", r"\end{tabular}"]
    escribir("tab_dualidad.tex", L)


def tabla_pem():
    p = cargar("reto2_pem.json")
    L = [r"\begin{tabular}{@{}P{0.9in}rrr@{}}", r"\toprule",
         r"Plan evaluado & 30 mercados & PEM 2m & PEM 2m+1 \\", r"\midrule"]
    nombres = {"1": "caso 1 (estr\\'es)", "2": "caso 2", "3": "caso 3", "4": "caso 4"}
    for c in ("1", "2", "3", "4"):
        v = p["estimador"][c]
        L.append(f"Plan del {nombres[c]} & {n(v[0], 1)} & {n(v[1], 1)} & {n(v[4], 1)} \\\\")
    L += [r"\bottomrule", r"\end{tabular}"]
    escribir("tab_pem_estimador.tex", L)

    o = p["opt"]
    cols = r"@{}clcP{1.7in}rr@{}"
    L = [f"\\begin{{tabular}}{{{cols}}}", r"\toprule",
         r"Caso & M\'etodo & Mercados & Plan HVAC / HVDC & Arrepentimiento (\MUSD) & Tiempo (s) \\", r"\midrule"]
    filas = [("2", "2-6", "6 niveles (paper)", 30), ("2", "2-2m", "PEM 2m", 10), ("2", "2-2m+1", "PEM 2m+1", 15),
             ("3", "3-6", "6 niveles (paper)", 30), ("3", "3-2m", "PEM 2m", 10), ("3", "3-2m+1", "PEM 2m+1", 15)]
    for caso, clave, met, nm in filas:
        r = o[clave]
        reg = n(r.get("regret", 0.0), 3)
        L.append(f"{caso} & {met} & {nm} & {plan(r['plan'])} & {reg} & {n(r['t'], 1)} \\\\")
        if clave in ("2-2m+1",):
            L.append(r"\midrule")
    L += [r"\bottomrule", r"\end{tabular}"]
    escribir("tab_pem_planes.tex", L)


def tabla_mc():
    """Metodologia 3: Monte Carlo + k-means (resultados/reto2_montecarlo.json)."""
    p = cargar("reto2_montecarlo.json")
    ks = [3, 6, 10, 20]
    L = [r"\begin{tabular}{@{}l" + "r" * (1 + len(ks)) + "@{}}", r"\toprule",
         "Plan evaluado & 30 merc. & " + " & ".join(f"K={k}" for k in ks) + r" \\", r"\midrule"]
    for c in ("1", "2", "3", "4"):
        v = p["estimador"][c]
        L.append(f"Plan del caso {c} & {n(v[0], 1)} & " + " & ".join(n(x, 1) for x in v[1:]) + r" \\")
    L += [r"\bottomrule", r"\end{tabular}"]
    escribir("tab_mc_estimador.tex", L)

    o = p["opt"]
    L = [r"\begin{tabular}{@{}clcP{2.1in}rrr@{}}", r"\toprule",
         r"Caso & M\'etodo & Merc. & Plan HVAC / HVDC & Inv. (\MUSD) & Arrepent. (\MUSD) & $t$ (s) \\", r"\midrule"]
    for caso in ("2", "3", "4"):
        claves = [(f"{caso}-6niveles", "6 niveles", 30)] + [(f"{caso}-K{k}", f"MC $K={k}$", 5 * k) for k in ks] + \
                 [(f"{caso}-K6-indep", "MC $K=6$ indep.", 30), (f"{caso}-K20-indep", "MC $K=20$ indep.", 100)]
        for clave, met, nm in claves:
            if clave not in o:
                continue
            r = o[clave]
            inv = r.get("inv")
            L.append(f"{caso} & {met} & {nm} & {plan(r['plan'])} & {n(inv, 1) if inv is not None else '--'} & "
                     f"{n(r.get('regret', 0.0), 3)} & {n(r['t'], 1)} \\\\")
        if caso != "4":
            L.append(r"\midrule")
    L += [r"\bottomrule", r"\end{tabular}"]
    escribir("tab_mc_planes.tex", L)


# ----------------------------------------------------------------------------- FIGURAS
def figuras():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    TINTA, SEC, MUDO, REJILLA, EJE = "#0b0b0b", "#52514e", "#898781", "#e1e0d9", "#c3c2b7"
    C = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100"]          # paleta categorica (slots 1-4)
    plt.rcParams.update({
        "font.family": "STIXGeneral", "mathtext.fontset": "stix", "font.size": 7.5,
        "axes.edgecolor": EJE, "axes.labelcolor": SEC, "xtick.color": SEC, "ytick.color": SEC,
        "axes.linewidth": 0.6, "xtick.major.width": 0.6, "ytick.major.width": 0.6,
        "axes.grid": True, "grid.color": REJILLA, "grid.linewidth": 0.5, "axes.axisbelow": True,
        "axes.spines.top": False, "axes.spines.right": False, "legend.frameon": False,
        "pdf.fonttype": 42, "savefig.bbox": "tight", "savefig.pad_inches": 0.03,
    })
    W = 3.45

    # --- Fig. datos digitalizados de la Fig. 2 de Heydari
    fig, ax = plt.subplots(2, 1, figsize=(W, 3.1))
    edges = [0]
    for h in H.N_H:
        edges.append(edges[-1] + h)
    for t, c in enumerate(H.CARGA):
        ax[0].hlines(c, edges[t], edges[t + 1], color=C[0], lw=1.6)
        if t < len(H.CARGA) - 1:
            ax[0].vlines(edges[t + 1], c, H.CARGA[t + 1], color=C[0], lw=1.0, ls=":")
    ax[0].set_ylabel("Carga (p.u.)")
    ax[0].set_xlabel("Horas acumuladas del año")
    ax[0].set_xlim(0, 8760)
    ax[0].set_ylim(0, 1.0)
    for t in range(5):
        ax[1].plot([t + 1] * 6, H.VIENTO[t], "o", ms=3.2, color=C[1], mec="white", mew=0.5)
        ax[1].plot([t + 0.78, t + 1.22], [sum(H.VIENTO[t]) / 6] * 2, color=SEC, lw=0.8)
    ax[1].set_xticks(range(1, 6))
    ax[1].set_xlabel("Bloque de la curva de duración")
    ax[1].set_ylabel("Viento (p.u. de la\ncapacidad instalada)")
    ax[1].set_ylim(0, 0.6)
    ax[1].set_xlim(0.5, 5.5)
    ax[0].text(0.01, 0.06, "(a)", transform=ax[0].transAxes, color=SEC)
    ax[1].text(0.01, 0.9, "(b)", transform=ax[1].transAxes, color=SEC)
    fig.tight_layout(h_pad=0.8)
    fig.savefig(os.path.join(OUT_F, "fig_datos_heydari.pdf"))
    plt.close(fig)

    # --- Fig. sensibilidad al coeficiente de demanda
    s = cargar("reto2_sensibilidad_demanda.json")
    mk = ["o", "s", "^", "D"]
    ls = ["-", "--", "-.", ":"]
    fig, ax = plt.subplots(2, 1, figsize=(W, 3.5), sharex=True)
    for i, cs in enumerate(("1", "2", "3", "4")):
        r = [d["rel"] for d in s[cs]]
        ax[0].plot(r, [d["inv"] for d in s[cs]], marker=mk[i], ls=ls[i], color=C[i], lw=1.2, ms=3.6, mec="white", mew=0.4,
                   label=f"Caso {cs}")
        ax[1].plot(r, [d["esw"] for d in s[cs]], marker=mk[i], ls=ls[i], color=C[i], lw=1.2, ms=3.6, mec="white", mew=0.4)
    for a in ax:
        a.axvline(1.0, color=MUDO, lw=0.6, ls=(0, (2, 2)))
    ax[0].set_ylabel("Inversión (M USD)")
    ax[1].set_ylabel("ESW (M USD/año)")
    ax[1].set_xlabel("Coeficiente de demanda relativo $r$ (1 = Tabla 4)")
    ax[0].legend(ncol=4, loc="upper center", bbox_to_anchor=(0.5, 1.22), handlelength=2.2, columnspacing=1.0, fontsize=7)
    ax[0].text(0.02, 0.9, "(a)", transform=ax[0].transAxes, color=SEC)
    ax[1].text(0.02, 0.06, "(b)", transform=ax[1].transAxes, color=SEC)
    fig.tight_layout(h_pad=0.8)
    fig.savefig(os.path.join(OUT_F, "fig_sensibilidad.pdf"))
    plt.close(fig)

    # --- Fig. error del estimador PEM
    p = cargar("reto2_pem.json")["estimador"]
    etq = ["Plan caso 1\n(estrés)", "Plan caso 2", "Plan caso 3", "Plan caso 4"]
    e2m = [p[c][3] for c in ("1", "2", "3", "4")]
    e2p = [p[c][6] for c in ("1", "2", "3", "4")]
    fig, ax = plt.subplots(figsize=(W, 2.2))
    y = list(range(4))
    h = 0.34
    ax.barh([v - h / 2 - 0.02 for v in y], e2m, height=h, color=C[0], label="PEM 2m (10 mercados)")
    ax.barh([v + h / 2 + 0.02 for v in y], e2p, height=h, color=C[1], label="PEM 2m+1 (15 mercados)")
    for v, a, b in zip(y, e2m, e2p):
        ax.text(a + (0.07 if a >= 0 else -0.07), v - h / 2 - 0.02, f"{a:+.2f}", va="center", ha="left" if a >= 0 else "right", fontsize=6.5, color=SEC)
        ax.text(b + (0.07 if b >= 0 else -0.07), v + h / 2 + 0.02, f"{b:+.2f}", va="center", ha="left" if b >= 0 else "right", fontsize=6.5, color=SEC)
    ax.axvline(0, color=TINTA, lw=0.7)
    ax.set_yticks(y)
    ax.set_yticklabels(etq)
    ax.invert_yaxis()
    ax.set_xlim(-3.6, 4.0)
    ax.set_xlabel("Error del ESW frente a los 30 mercados (%)")
    ax.legend(loc="lower center", bbox_to_anchor=(0.5, 1.0), ncol=2, fontsize=6.8, handlelength=1.2, columnspacing=1.2)
    ax.grid(axis="y", visible=False)
    fig.savefig(os.path.join(OUT_F, "fig_pem_error.pdf"))
    plt.close(fig)

    # --- Fig. error del RTS-24: bloques exactos vs impresos
    filas = _err_rts()
    fig, ax = plt.subplots(figsize=(W, 2.3))
    x = list(range(len(filas)))
    ax.plot(x, [e - p_ for _, p_, e, _ in filas], "o", color=C[0], ms=4.2, mec="white", mew=0.5, label="Bloques exactos")
    ax.plot(x, [i - p_ for _, p_, _, i in filas], "s", color=C[1], ms=4.2, mec="white", mew=0.5, label="Bloques impresos")
    ax.axhline(0, color=TINTA, lw=0.7)
    ax.set_xticks(x)
    etqs = ["VIII\nbil.", "VIII\nmin.1", "VIII\nmin.2", "VIII\nmin.3"] +[f.replace("-", "–") for f, *_ in filas[4:10]] + ["X"]
    ax.set_xticklabels(etqs, fontsize=6.3)
    ax.set_ylabel("Error del bienestar medio\n(M EUR/año)")
    ax.set_ylim(-0.05, 0.25)
    ax.axvline(3.5, color=MUDO, lw=0.5, ls=":")
    ax.axvline(9.5, color=MUDO, lw=0.5, ls=":")
    ax.text(1.5, 0.235, "Tabla VIII", ha="center", color=SEC, fontsize=6.5)
    ax.text(6.5, 0.235, "Cuadro 6.9 (línea fuera)", ha="center", color=SEC, fontsize=6.5)
    ax.legend(loc="center right", bbox_to_anchor=(1.0, 0.58), fontsize=6.8)
    ax.grid(axis="x", visible=False)
    fig.savefig(os.path.join(OUT_F, "fig_rts_bloques.pdf"))
    plt.close(fig)


if __name__ == "__main__":
    tabla_garver()
    tabla_garver_cont()
    tabla_rts_viii()
    mae_e, mae_i, nn = tabla_rts_resto()
    tabla_heydari()
    tabla_dualidad()
    tabla_pem()
    if os.path.exists(os.path.join(RES, "reto2_montecarlo.json")):
        tabla_mc()
    figuras()
    print(f"RTS-24: {nn} cifras; error abs. medio exactos = {mae_e:.4f}, impresos = {mae_i:.4f}")
    print("tablas ->", OUT_T, sorted(os.listdir(OUT_T)))
    print("figuras ->", OUT_F, sorted(os.listdir(OUT_F)))
