# Reto 1 - IEEE RTS-24, contingencia simple (tesis, Cuadro 6.9)

Cuatro escenarios (pesos 0.40/0.25/0.25/0.10); presupuesto 23 M EUR. El paper no publica este caso; los datos de comparacion son del Cuadro 6.9 de la tesis. Se corre con bloques *exactos* (inferencia, ver reporte del caso sin contingencias) y con bloques *impresos* de la Tabla VI; ademas de la formulacion de dualidad se corre el oraculo de un nivel como control.

| Linea fuera | Bloques | Plan tesis | Plan reproducido | Inv. tesis | Inv. reprod. | Bienestar medio tesis | Bienestar medio reprod. | Objetivo del plan tesis = optimo | Obj. dualidad | Obj. oraculo | Racion. max. (MW) | max abs(phi) | CPU tesis (min) | CPU Gurobi dualidad / oraculo (min) |
|---|---|---|---|---:|---:|---:|---:|:--:|---:|---:|---:|---:|---:|---:|
| 11-13 | exactos | 6-10, 10-11, 11-13, 14-23 | 6-10, 10-11, 11-13, 14-23 | 22.99 | 22.99 | 740.39 | 740.39 | si | 738.088154 | 738.088154 | 0.00 | 242.0 | 4.59 | 0.11 / 0.01 |
| 11-13 | impresos | 6-10, 10-11, 11-13, 14-23 | 6-10, 10-11, 11-13, 14-23 | 22.99 | 22.99 | 740.39 | 740.57 | si | 738.275880 | 738.275880 | 0.00 | 242.0 | 4.59 | 0.10 / 0.01 |
| 11-14 | exactos | 6-10, 10-11, 11-13, 14-23 | 6-10, 10-11, 11-13, 14-23 | 22.99 | 22.99 | 740.24 | 740.24 | si | 737.943929 | 737.943929 | 0.00 | 242.0 | 4.20 | 0.07 / 0.01 |
| 11-14 | impresos | 6-10, 10-11, 11-13, 14-23 | 6-10, 10-11, 11-13, 14-23 | 22.99 | 22.99 | 740.24 | 740.43 | si | 738.131831 | 738.131831 | 0.00 | 242.0 | 4.20 | 0.13 / 0.01 |
| 12-13 | exactos | 6-10, 10-11, 11-13, 14-23 | 6-10, 10-11, 11-13, 14-23 | 22.99 | 22.99 | 740.00 | 740.00 | si | 737.703176 | 737.703176 | 0.00 | 242.0 | 4.96 | 0.12 / 0.01 |
| 12-13 | impresos | 6-10, 10-11, 11-13, 14-23 | 6-10, 10-11, 11-13, 14-23 | 22.99 | 22.99 | 740.00 | 740.19 | si | 737.890903 | 737.890903 | 0.00 | 242.0 | 4.96 | 0.13 / 0.01 |
| 12-23 | exactos | 5-10, 6-10, 7-8 (2), 10-11, 14-23 | 5-10, 6-10, 7-8 (2), 10-11, 14-23 | 22.81 | 22.81 | 713.02 | 713.02 | si | 710.738144 | 710.738144 | 0.00 | 51.1 | 16.19 | 0.23 / 0.01 |
| 12-23 | impresos | 5-10, 6-10, 7-8 (2), 10-11, 14-23 | 5-10, 6-10, 7-8 (2), 10-11, 14-23 | 22.81 | 22.81 | 713.02 | 713.21 | si | 710.924513 | 710.924513 | 0.00 | 51.1 | 16.19 | 0.20 / 0.02 |
| 14-16 | exactos | 6-10, 7-8, 10-12, 14-16, 13-14 | 6-10, 7-8, 10-12, 13-14, 14-16 | 22.19 | 22.19 | 725.42 | 725.42 | si | 723.203001 | 723.203001 | 0.00 | 38.6 | 6.21 | 0.14 / 0.01 |
| 14-16 | impresos | 6-10, 7-8, 10-12, 14-16, 13-14 | 6-10, 7-8, 10-12, 13-14, 14-16 | 22.19 | 22.19 | 725.42 | 725.61 | si | 723.389763 | 723.389763 | 0.00 | 38.6 | 6.21 | 0.16 / 0.01 |
| 15-24 | exactos | 3-9, 6-10, 7-8 (2), 10-12, 13-14 | 3-9, 6-10, 7-8 (2), 10-12, 13-14 | 22.27 | 22.27 | 711.89 | 711.89 | si | 709.658008 | 709.658008 | 0.00 | 38.9 | 7.38 | 0.10 / 0.01 |
| 15-24 | impresos | 3-9, 6-10, 7-8 (2), 10-12, 13-14 | 3-9, 6-10, 7-8 (2), 10-12, 13-14 | 22.27 | 22.27 | 711.89 | 712.07 | si | 709.845516 | 709.845516 | 0.00 | 38.9 | 7.38 | 0.15 / 0.01 |

(*) plan distinto al de la tesis (solo en el orden de escritura o por optimo alternativo); la columna 'Objetivo del plan tesis = optimo' indica si el plan de la tesis alcanza el mismo objetivo.
