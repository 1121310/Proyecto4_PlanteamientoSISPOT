# Reto 2 - Garver de Heydari (2024): metodo 1, segmentacion por curva de duracion

5 bloques de la curva de duracion (1000/3000/3000/1000/760 h) x 6 intensidades de viento equiprobables = 30 mercados (caso 1, sin viento: 5). Carga y viento **digitalizados de la Fig. 2** (datos inferidos, ~0.002 p.u.). Comparacion con la Tabla 4 en dos pruebas por caso: (a) *prueba de datos*: el plan publicado evaluado con mis datos; (b) *prueba de optimalidad*: el optimo de mi modelo (MILP de un nivel, verificado contra la formulacion de dualidad en `reto2_garver.py dual`) frente al plan publicado.


## Caso 1 (solo termicas)

| | Paper (Tabla 4) | Reproducido, plan publicado | Dif. |
|---|---:|---:|---:|
| Plan HVAC / HVDC | 2-6 (4), 3-5 (3) / - | 2-6 (4), 3-5 (3) / - | |
| Inversion total (M$) | 180.0 | 180.0 | exacta |
| Bienestar esperado ESW (M$) | 462.64 | 462.844 | +0.04 % |
| Funcion objetivo del nivel superior (M$) | 442.81 | 443.014 | +0.05 % |
| Energia termica (GWh) | 9627.92 | 9632.4 (rango de empates 9632.4-9632.4) | fuera del rango (+0.05 % el limite mas cercano) |
| Energia eolica (GWh) | - | 0.0 | - |
| Consumo (GWh) | 9627.92 | 9632.4 (rango 9632.4-9632.4) | fuera del rango (+0.05 % el limite mas cercano) |
| LMP medio ($/MWh) | 78.1 | 78.100 | +0.00 % |
| Desv. tipica de LMP ($/MWh) | 6.104 | 6.104 | -0.00 % |

*Prueba de optimalidad.* Optimo de mi modelo: **2-6 (4), 3-5 (3)**, inversion 180.0 M$, objetivo 443.014 M$ (OPTIMO, gap 0.0e+00, 0.1 s; recalculado con LP de plan fijo: diferencia -5.7e-14). **Coincide con el plan publicado** (arrepentimiento 0).

Variante *4 circuitos HVAC por corredor contando el existente*: plan 2-6 (4), 3-5 (3) (igual).

## Caso 2 (eolica, solo HVAC)

| | Paper (Tabla 4) | Reproducido, plan publicado | Dif. |
|---|---:|---:|---:|
| Plan HVAC / HVDC | 2-6 (4), 3-5 (2), 4-6 (2), 5-6 (2) / - | 2-6 (4), 3-5 (2), 4-6 (2), 5-6 (2) / - | |
| Inversion total (M$) | 342.0 | 342.0 | exacta |
| Bienestar esperado ESW (M$) | 527.62 | 529.305 | +0.32 % |
| Funcion objetivo del nivel superior (M$) | 489.94 | 491.628 | +0.34 % |
| Energia termica (GWh) | 7120.48 | 7020.4 (rango de empates 7012.1-7123.1) | dentro del rango |
| Energia eolica (GWh) | 2213.81 | 2227.1 | +0.60 % |
| Consumo (GWh) | 9400.21 | 9313.1 (rango 9304.8-9415.7) | dentro del rango |
| Racionamiento (GWh) = consumo - termica - eolica | 65.92 | 65.54 | -0.57 % |
| LMP medio ($/MWh) | 236.186 | 236.186 | +0.00 % |
| Desv. tipica de LMP ($/MWh) | 376.042 | 376.042 | -0.00 % |

*Prueba de optimalidad.* Optimo de mi modelo: **2-6 (4), 3-5 (2), 4-6 (2), 5-6 (2)**, inversion 342.0 M$, objetivo 491.628 M$ (OPTIMO, gap 0.0e+00, 2.6 s; recalculado con LP de plan fijo: diferencia 1.8e-11). **Coincide con el plan publicado** (arrepentimiento 0).

Variante *4 circuitos HVAC por corredor contando el existente*: plan 2-6 (4), 3-5 (2), 4-6 (2), 5-6 (2) (igual).

*Sensibilidad (no es un ajuste)*: con el viento digitalizado escalado por 0.9940 (el factor que iguala la energia eolica publicada, 2213.81 GWh), el plan publicado da ESW = 527.642 M$ (+0.00 % vs paper) y el optimo sigue siendo el publicado.

## Caso 3 (eolica, HVAC + HVDC)

| | Paper (Tabla 4) | Reproducido, plan publicado | Dif. |
|---|---:|---:|---:|
| Plan HVAC / HVDC | 2-6 (4), 3-5 (3), 3-6, 4-6 (2) / 2-6 | 2-6 (4), 3-5 (3), 3-6, 4-6 (2) / 2-6 | |
| Inversion total (M$) | 342.6 | 342.6 | exacta |
| Bienestar esperado ESW (M$) | 530.73 | 532.415 | +0.32 % |
| Funcion objetivo del nivel superior (M$) | 492.98 | 494.672 | +0.34 % |
| Energia termica (GWh) | 7138.66 | 7065.2 (rango de empates 7022.4-7141.5) | dentro del rango |
| Energia eolica (GWh) | 2213.81 | 2227.1 | +0.60 % |
| Consumo (GWh) | 9415.87 | 9355.3 (rango 9312.5-9431.6) | dentro del rango |
| Racionamiento (GWh) = consumo - termica - eolica | 63.40 | 63.02 | -0.59 % |
| LMP medio ($/MWh) | 193.301 | 193.301 | +0.00 % |
| Desv. tipica de LMP ($/MWh) | 338.956 | 338.956 | -0.00 % |

*Prueba de optimalidad.* Optimo de mi modelo: **2-6 (4), 3-5 (3), 3-6, 4-6 (2)  |  HVDC: 2-6**, inversion 342.6 M$, objetivo 494.672 M$ (OPTIMO, gap 0.0e+00, 3.1 s; recalculado con LP de plan fijo: diferencia -3.1e-12). **Coincide con el plan publicado** (arrepentimiento 0).

Variante *4 circuitos HVAC por corredor contando el existente*: plan 2-6 (4), 3-5 (3), 3-6, 4-6 (2)  |  HVDC: 2-6 (igual).

*Sensibilidad (no es un ajuste)*: con el viento digitalizado escalado por 0.9940 (el factor que iguala la energia eolica publicada, 2213.81 GWh), el plan publicado da ESW = 530.866 M$ (+0.03 % vs paper) y el optimo sigue siendo el publicado.

## Caso 4 (eolica, HVAC + HVDC, CVaR)

| | Paper (Tabla 4) | Reproducido, plan publicado | Dif. |
|---|---:|---:|---:|
| Plan HVAC / HVDC | 2-6 (4), 3-5 (3), 4-6 (3) / 2-6 | 2-6 (4), 3-5 (3), 4-6 (3) / 2-6 | |
| Inversion total (M$) | 324.6 | 324.6 | exacta |
| Bienestar esperado ESW (M$) | 526.25 | 527.887 | +0.31 % |
| CVaR (M$) | 232.38 | 234.517 | +0.92 % |
| Funcion objetivo del nivel superior (M$) | 1652.41 | 1664.712 | +0.74 % |
| Energia termica (GWh) | 7119.39 | 7059.3 (rango de empates 7012.5-7123.4) | dentro del rango |
| Energia eolica (GWh) | 2210.24 | 2223.4 | +0.60 % |
| Consumo (GWh) | 9396.5 | 9349.3 (rango 9302.5-9413.4) | dentro del rango |
| Racionamiento (GWh) = consumo - termica - eolica | 66.87 | 66.54 | -0.49 % |
| LMP medio ($/MWh) | 243.29 | 243.734 | +0.18 % |
| Desv. tipica de LMP ($/MWh) | 393.51 | 394.615 | +0.28 % |

*Prueba de optimalidad.* Optimo de mi modelo: **2-6 (4), 3-5 (3), 4-6 (3)  |  HVDC: 2-6**, inversion 324.6 M$, objetivo 1664.712 M$ (OPTIMO, gap 0.0e+00, 4.1 s; recalculado con LP de plan fijo: diferencia 1.9e-10). **Coincide con el plan publicado** (arrepentimiento 0).

Variante *4 circuitos HVAC por corredor contando el existente*: plan 2-6 (4), 3-5 (3), 4-6 (3)  |  HVDC: 2-6 (igual).

*Sensibilidad (no es un ajuste)*: con el viento digitalizado escalado por 0.9940 (el factor que iguala la energia eolica publicada, 2213.81 GWh), el plan publicado da ESW = 526.269 M$ (+0.00 % vs paper), CVaR = 233.612 M$ (+0.53 %) y el optimo sigue siendo el publicado.

## Notas

* **LMP**: el paper no define sus estadisticos. La media y la desviacion tipica poblacional de los pares (caso, barra), sin ponderar por horas, reproducen la Tabla 4 en los casos 1-3 con 4-6 cifras; en el caso 4 difiere 0.2-0.3 %. Los LMP son constantes a trozos, por eso no dependen de la resolucion de la digitalizacion; validan precios, red y estructura de racionamiento, no los niveles de viento.
* **Energias**: hay empates de precio (p. ej. 77 $/MWh en una oferta y una demanda), de modo que el despacho optimo no es unico. Se da el rango sobre todos los despachos igualmente optimos; los valores publicados de energia termica y consumo caen dentro. El racionamiento y la energia eolica si son unicos.