# Reto 2 - metodo 3: simulacion Monte Carlo + reduccion de escenarios (k-means)

El enunciado no nombra la tercera metodologia; se eligio esta. En cada bloque la intensidad eolica sigue una Beta ajustada por momentos (media y varianza) a los 6 niveles del paper. Se generan N = 2000 escenarios anuales (semilla 2026); por defecto las muestras de los bloques se emparejan por rango (comonotonas), que es la dependencia implicita en los escenarios de riesgo del paper (el w-esimo nivel de cada bloque). k-means reduce los N vectores a K escenarios con probabilidad igual a la fraccion de muestras del grupo; cada escenario aporta 5 mercados y un grupo de riesgo, de modo que, a diferencia del PEM, permite el CVaR del caso 4. Los planes se comparan evaluandolos con los 30 mercados de referencia (6 niveles) y sus grupos de riesgo.

## Distribucion Beta por bloque y escenarios reducidos (K = 6, comonotono)

| Bloque | Beta (a, b) | media 6 niveles | media Monte Carlo | media reducida |
|---|---|---:|---:|---:|
| 1 | (2.296, 6.944) | 0.2485 | 0.2483 | 0.2483 |
| 2 | (2.151, 6.736) | 0.2420 | 0.2396 | 0.2396 |
| 3 | (2.580, 9.081) | 0.2212 | 0.2204 | 0.2204 |
| 4 | (2.208, 5.746) | 0.2776 | 0.2832 | 0.2832 |
| 5 | (1.813, 4.902) | 0.2700 | 0.2693 | 0.2693 |

Probabilidades de los 6 escenarios: 0.052, 0.124, 0.180, 0.225, 0.231, 0.188

## Exactitud del estimador del ESW (M$) de los planes publicados, sistema del caso 3

| Plan (caso) | 6 niveles (30 LP) | MC K=3 (15 LP) | MC K=6 (30 LP) | MC K=10 (50 LP) | MC K=20 (100 LP) |
|---|---:|---:|---:|---:|---:|
| caso 1 | -241.196 | -238.423 (+1.15 %) | -249.099 (-3.28 %) | -249.238 (-3.33 %) | -250.169 (-3.72 %) |
| caso 2 | 529.305 | 533.930 (+0.87 %) | 533.120 (+0.72 %) | 531.180 (+0.35 %) | 529.101 (-0.04 %) |
| caso 3 | 532.415 | 540.271 (+1.48 %) | 536.488 (+0.77 %) | 534.504 (+0.39 %) | 532.313 (-0.02 %) |
| caso 4 | 527.887 | 532.681 (+0.91 %) | 531.843 (+0.75 %) | 529.932 (+0.39 %) | 527.832 (-0.01 %) |

## Plan optimo con cada reduccion

Arrepentimiento = objetivo (1) del plan de 6 niveles menos el del plan del metodo, ambos evaluados con los 30 mercados y los 6 grupos de riesgo de referencia (en el caso 4 incluye beta x CVaR).

| Caso | Metodo | mercados | Estado | Plan HVAC / HVDC | Inv. (M$) | Objetivo propio | CVaR propio | Objetivo con 6 niveles | Arrepentimiento (M$) | t (s) |
|---|---|---:|---|---|---:|---:|---:|---:|---:|---:|
| 2 | 6 niveles (paper) | 30 | OPTIMO | 2-6 (4), 3-5 (2), 4-6 (2), 5-6 (2) / - | 342.0 | 491.628 | 0.000 | 491.628 | 0 | 8.4 |
| 2 | MC K=3 | 15 | OPTIMO | 2-6 (4), 3-5 (2), 4-6 (3), 5-6 (2) / - | 372.0 | 499.288 | 0.000 | 491.435 | 0.193 | 4.5 |
| 2 | MC K=6 | 30 | OPTIMO | 2-3, 2-6 (4), 3-5 (2), 4-6 (2), 5-6 (2) / - | 362.0 | 495.576 | 0.000 | 490.545 | 1.082 | 11.1 |
| 2 | MC K=10 | 50 | OPTIMO | 2-6 (4), 3-5 (2), 4-6 (3), 5-6 (2) / - | 372.0 | 493.531 | 0.000 | 491.435 | 0.193 | 19.0 |
| 2 | MC K=20 | 100 | OPTIMO | 2-6 (4), 3-5 (2), 4-6 (2), 5-6 (2) / - | 342.0 | 491.424 | 0.000 | 491.628 | 0.000 | 65.5 |
| 2 | MC K=6 (bloques independientes) | 30 | OPTIMO | 2-6 (4), 3-5 (2), 4-6 (2), 5-6 (2) / - | 342.0 | 520.571 | 0.000 | 491.628 | 0.000 | 10.6 |
| 2 | MC K=20 (bloques independientes) | 100 | OPTIMO | 2-6 (4), 3-5 (2), 4-6 (2), 5-6 (2) / - | 342.0 | 505.935 | 0.000 | 491.628 | 0.000 | 38.5 |
| 3 | 6 niveles (paper) | 30 | OPTIMO | 2-6 (4), 3-5 (3), 3-6, 4-6 (2) / 2-6 | 342.6 | 494.672 | 0.000 | 494.672 | 0 | 19.8 |
| 3 | MC K=3 | 15 | OPTIMO | 2-6 (4), 3-5 (3), 3-6, 4-6 (2) / 2-6 | 342.6 | 502.527 | 0.000 | 494.672 | 0.000 | 8.7 |
| 3 | MC K=6 | 30 | OPTIMO | 2-6 (4), 3-5 (3), 3-6, 4-6 (2) / 2-6 | 342.6 | 498.745 | 0.000 | 494.672 | 0.000 | 17.2 |
| 3 | MC K=10 | 50 | OPTIMO | 2-6 (4), 3-5 (3), 3-6, 4-6 (2) / 2-6 | 342.6 | 496.760 | 0.000 | 494.672 | 0.000 | 34.9 |
| 3 | MC K=20 | 100 | OPTIMO | 2-6 (4), 3-5 (3), 3-6, 4-6 (2) / 2-6 | 342.6 | 494.570 | 0.000 | 494.672 | 0.000 | 67.7 |
| 3 | MC K=6 (bloques independientes) | 30 | OPTIMO | 2-6 (4), 3-5 (3), 3-6, 4-6 (2) / 2-6 | 342.6 | 523.118 | 0.000 | 494.672 | 0.000 | 15.9 |
| 3 | MC K=20 (bloques independientes) | 100 | OPTIMO | 2-6 (4), 3-5 (3), 3-6, 4-6 (2) / 2-6 | 342.6 | 507.318 | 0.000 | 494.672 | 0.000 | 77.9 |
| 4 | 6 niveles (paper) | 30 | OPTIMO | 2-6 (4), 3-5 (3), 4-6 (3) / 2-6 | 324.6 | 1664.712 | 234.517 | 1664.712 | 0 | 11.4 |
| 4 | MC K=3 | 15 | OPTIMO | 2-6 (4), 3-5 (3), 4-6 (2) / 2-6 | 294.6 | 2099.924 | 322.782 | 1615.949 | 48.764 | 6.1 |
| 4 | MC K=6 | 30 | OPTIMO | 2-6 (4), 3-5 (3), 4-6 (2) / 2-6 | 294.6 | 1725.788 | 248.166 | 1615.949 | 48.764 | 12.7 |
| 4 | MC K=10 | 50 | OPTIMO | 2-6 (4), 3-5 (3), 4-6 (3) / 2-6 | 324.6 | 1711.013 | 243.368 | 1664.712 | 0.000 | 42.5 |
| 4 | MC K=20 | 100 | OPTIMO | 2-6 (4), 3-5 (3), 4-6 (3) / 2-6 | 324.6 | 1641.752 | 229.936 | 1664.712 | 0.000 | 75.8 |
| 4 | MC K=6 (bloques independientes) | 30 | OPTIMO | 2-6 (4), 3-5 (3), 4-6 (3) / 2-6 | 324.6 | 2607.180 | 417.018 | 1664.712 | 0.000 | 14.1 |
| 4 | MC K=20 (bloques independientes) | 100 | OPTIMO | 2-6 (4), 3-5 (3), 4-6 (2) / 2-6 | 294.6 | 2508.294 | 402.250 | 1615.949 | 48.764 | 111.0 |